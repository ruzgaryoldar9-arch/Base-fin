# Base Finder Pro (Fabric 1.21.11) — starter implementation

This repository is a **GUI and module-registry foundation**, not a completed 100+ module scanner. It includes a Right Shift keybinding, ESC close behavior, category tabs, search, module toggles, scrolling, a settings popup, and UI accent swatches.

## Compatibility status
- Target: Minecraft Java Edition 1.21.11
- Java: 21
- Loom: 1.14 line, as recommended by Fabric's 1.21.11 announcement
- Fabric Loader/API/Yarn versions in `gradle.properties` are candidate coordinates and must be checked against Fabric's version selector before building. Version catalogs can change and exact artifact availability was not validated in this generated archive.
- This archive has **not been compiled here**. Do not treat it as build-verified.

## Build
1. Install a JDK 21 and Gradle-compatible environment.
2. Verify `yarn_mappings`, `loader_version`, `fabric_version`, and `loom_version` in `gradle.properties` against Fabric's version selector for 1.21.11.
3. From the project directory run `./gradlew build` (Windows: `gradlew.bat build`).
4. Place the built jar from `build/libs/` in `.minecraft/mods/` alongside Fabric API.

## Current limitations
- The module list contains illustrative toggles; most do not yet run a world scanner or renderer.
- ESP swatches currently change the GUI accent; per-module ESP color persistence and actual world rendering still need implementation.
- The GUI uses the standard Screen lifecycle so mouse focus and game input are handled by Minecraft.
- Search is filtered within the selected category.
- This implementation deliberately does not inspect unloaded chunks or bypass server access controls.
