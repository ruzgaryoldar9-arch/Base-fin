package dev.basefinderpro.module;

public final class ModuleSetting<T> {
    private final String name;
    private T value;
    public ModuleSetting(String name, T initialValue) {
        this.name = name;
        this.value = initialValue;
    }
    public String name() { return name; }
    public T value() { return value; }
    public void setValue(T value) { this.value = value; }
}
