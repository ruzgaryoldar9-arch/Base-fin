package dev.basefinderpro.module;

import java.util.LinkedHashMap;
import java.util.Map;

public final class Module {
    private final String name;
    private final String description;
    private final ModuleCategory category;
    private boolean enabled;
    private final Map<String, ModuleSetting<?>> settings = new LinkedHashMap<>();

    public Module(String name, String description, ModuleCategory category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }
    public String name() { return name; }
    public String description() { return description; }
    public ModuleCategory category() { return category; }
    public boolean enabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public Map<String, ModuleSetting<?>> settings() { return settings; }
    public Module addSetting(ModuleSetting<?> setting) {
        settings.put(setting.name(), setting);
        return this;
    }
}
