package dev.basefinderpro.module;

public enum ModuleCategory {
    CHUNK("Chunk"),
    STORAGE("Storage ESP"),
    BASE_FINDER("Base Finder"),
    BLOCK_FINDER("Block Finder"),
    CAVE("Cave Explorer"),
    NAVIGATION("Navigation"),
    ANALYSIS("Analysis"),
    INTERFACE("Interface"),
    PERFORMANCE("Performance"),
    DATA("Data");

    private final String title;
    ModuleCategory(String title) { this.title = title; }
    public String title() { return title; }
}
