package dev.basefinderpro.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleRegistry {
    private static final List<Module> MODULES = new ArrayList<>();
    private static boolean registered;

    private ModuleRegistry() {}

    public static void registerDefaults() {
        if (registered) return;
        registered = true;
        add("Chunk Coordinates", "Shows coordinates for the current chunk.", ModuleCategory.CHUNK);
        add("Chunk Borders", "Displays borders for the current chunk.", ModuleCategory.CHUNK);
        add("Loaded Chunk Map", "Maps chunks currently available to the client.", ModuleCategory.CHUNK);
        add("Chest ESP", "Highlights accessible chest block entities.", ModuleCategory.STORAGE)
                .addSetting(new ModuleSetting<>("ESP color", 0xFF55D6FF));
        add("Barrel ESP", "Highlights accessible barrels.", ModuleCategory.STORAGE)
                .addSetting(new ModuleSetting<>("ESP color", 0xFFFFB347));
        add("Container Distance", "Displays distance to detected containers.", ModuleCategory.STORAGE);
        add("Base Candidate Detector", "Scores structural patterns in loaded blocks only.", ModuleCategory.BASE_FINDER);
        add("Tunnel Detector", "Looks for connected, tunnel-like block patterns in scanned data.", ModuleCategory.BASE_FINDER);
        add("Entrance Detector", "Flags possible entrances in scanned terrain.", ModuleCategory.BASE_FINDER);
        add("Obsidian Finder", "Finds selected obsidian blocks in accessible chunks.", ModuleCategory.BLOCK_FINDER);
        add("Ladder Finder", "Finds ladders in accessible chunks.", ModuleCategory.BLOCK_FINDER);
        add("Cave Entrance Markers", "Marks cave entrances that have been observed.", ModuleCategory.CAVE);
        add("Height Map", "Builds a height map from available surface data.", ModuleCategory.CAVE);
        add("Coordinates HUD", "Shows player coordinates in the HUD.", ModuleCategory.NAVIGATION);
        add("Waypoints", "Stores local navigation markers.", ModuleCategory.NAVIGATION);
        add("Block Density", "Summarizes scanned block counts.", ModuleCategory.ANALYSIS);
        add("Storage Cluster Analysis", "Groups nearby discovered storage blocks.", ModuleCategory.ANALYSIS);
        add("Incremental Scanning", "Processes scan work in bounded batches.", ModuleCategory.PERFORMANCE);
        add("Duplicate Result Filter", "Removes duplicate scan results.", ModuleCategory.PERFORMANCE);
        add("Search History", "Keeps local search history.", ModuleCategory.DATA);
        add("JSON Configuration", "Persists client preferences in JSON.", ModuleCategory.DATA);
    }

    private static Module add(String name, String description, ModuleCategory category) {
        Module module = new Module(name, description, category);
        MODULES.add(module);
        return module;
    }

    public static List<Module> all() { return Collections.unmodifiableList(MODULES); }
    public static List<Module> inCategory(ModuleCategory category) {
        return MODULES.stream().filter(m -> m.category() == category).toList();
    }
}
