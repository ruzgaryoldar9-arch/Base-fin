package dev.basefinderpro;

import dev.basefinderpro.gui.BaseFinderScreen;
import dev.basefinderpro.module.ModuleRegistry;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class BaseFinderProClient implements ClientModInitializer {
    public static final String MOD_ID = "basefinderpro";
    private static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        ModuleRegistry.registerDefaults();
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.basefinderpro.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen instanceof BaseFinderScreen) {
                    client.setScreen(null);
                } else if (client.currentScreen == null) {
                    client.setScreen(new BaseFinderScreen());
                }
            }
        });
    }
}
