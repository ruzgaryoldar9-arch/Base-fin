package dev.basefinderpro.gui;

import dev.basefinderpro.module.Module;
import dev.basefinderpro.module.ModuleCategory;
import dev.basefinderpro.module.ModuleRegistry;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class BaseFinderScreen extends Screen {
    private ModuleCategory selectedCategory = ModuleCategory.CHUNK;
    private TextFieldWidget search;
    private int scroll;
    private int accent = 0xFF53C8FF;
    private Module settingsModule;
    private int panelX, panelY, panelW = 430, panelH = 300;
    private static final int ROW_H = 27;

    public BaseFinderScreen() {
        super(Text.literal("Base Finder Pro"));
    }

    @Override
    protected void init() {
        panelW = Math.min(520, Math.max(360, width - 32));
        panelH = Math.min(340, Math.max(240, height - 32));
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;
        search = new TextFieldWidget(textRenderer, panelX + 12, panelY + 42, panelW - 24, 20,
                Text.literal("Search modules"));
        search.setPlaceholder(Text.literal("Search modules..."));
        addSelectableChild(search);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        ctx.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xF0181D29);
        ctx.fill(panelX, panelY, panelX + panelW, panelY + 3, accent);
        ctx.drawText(textRenderer, "BASE FINDER PRO", panelX + 12, panelY + 12, 0xFFFFFFFF, false);
        ctx.drawText(textRenderer, "CLIENT ANALYSIS  /  1.21.11", panelX + panelW - 166,
                panelY + 14, 0xFF9AA7BA, false);
        search.render(ctx, mouseX, mouseY, delta);

        int tabY = panelY + 70;
        int tabW = (panelW - 24) / 5;
        ModuleCategory[] categories = ModuleCategory.values();
        for (int i = 0; i < categories.length; i++) {
            int col = i % 5;
            int row = i / 5;
            int x = panelX + 12 + col * tabW;
            int y = tabY + row * 24;
            int color = categories[i] == selectedCategory ? accent : 0xFF2A3140;
            ctx.fill(x, y, x + tabW - 3, y + 20, color);
            String title = categories[i].title();
            if (textRenderer.getWidth(title) > tabW - 10) title = title.substring(0, Math.min(7, title.length()));
            ctx.drawCenteredTextWithShadow(textRenderer, title, x + (tabW - 3) / 2, y + 6,
                    categories[i] == selectedCategory ? 0xFF101722 : 0xFFE4EAF2);
        }

        int listY = panelY + 122;
        int listBottom = panelY + panelH - 16;
        ctx.enableScissor(panelX + 10, listY, panelX + panelW - 10, listBottom);
        List<Module> modules = filteredModules();
        int maxVisible = Math.max(0, (listBottom - listY) / ROW_H);
        for (int i = 0; i < modules.size(); i++) {
            int y = listY + i * ROW_H - scroll;
            if (y + ROW_H < listY || y > listBottom) continue;
            Module module = modules.get(i);
            ctx.fill(panelX + 12, y, panelX + panelW - 12, y + ROW_H - 2,
                    module.enabled() ? 0xFF263C49 : 0xFF222936);
            ctx.drawText(textRenderer, module.name(), panelX + 20, y + 5, 0xFFF0F4FA, false);
            int toggleX = panelX + panelW - 90;
            ctx.fill(toggleX, y + 5, toggleX + 42, y + 21,
                    module.enabled() ? 0xFF2BAE82 : 0xFF505968);
            ctx.drawCenteredTextWithShadow(textRenderer, module.enabled() ? "ON" : "OFF",
                    toggleX + 21, y + 9, 0xFFFFFFFF);
            ctx.drawText(textRenderer, "⚙", panelX + panelW - 36, y + 6, 0xFFB8C4D6, false);
        }
        ctx.disableScissor();

        if (settingsModule != null) renderSettings(ctx);
        ctx.drawText(textRenderer, "Right Shift: toggle GUI    ESC: close",
                panelX + 12, panelY + panelH - 12, 0xFF9AA7BA, false);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private List<Module> filteredModules() {
        String q = search == null ? "" : search.getText().toLowerCase(Locale.ROOT);
        List<Module> out = new ArrayList<>();
        for (Module m : ModuleRegistry.inCategory(selectedCategory)) {
            if (m.name().toLowerCase(Locale.ROOT).contains(q)
                    || m.description().toLowerCase(Locale.ROOT).contains(q)) out.add(m);
        }
        return out;
    }

    private void renderSettings(DrawContext ctx) {
        int x = panelX + panelW / 2 - 115, y = panelY + panelH / 2 - 65;
        ctx.fill(x, y, x + 230, y + 130, 0xFF111722);
        ctx.fill(x, y, x + 230, y + 2, accent);
        ctx.drawText(textRenderer, settingsModule.name(), x + 12, y + 12, 0xFFFFFFFF, false);
        ctx.drawText(textRenderer, settingsModule.description(), x + 12, y + 34, 0xFFB7C1D0, false);
        ctx.drawText(textRenderer, "ESP accent:", x + 12, y + 65, 0xFFFFFFFF, false);
        int[] colors = {0xFF53C8FF, 0xFFFFB347, 0xFFFF6B8A, 0xFF8BE28B, 0xFFC69BFF};
        for (int i = 0; i < colors.length; i++) {
            int cx = x + 12 + i * 40;
            ctx.fill(cx, y + 82, cx + 30, y + 104, colors[i]);
            if (accent == colors[i]) ctx.drawBorder(cx - 1, y + 81, 32, 24, 0xFFFFFFFF);
        }
        ctx.drawText(textRenderer, "Click a swatch; click outside to close",
                x + 12, y + 113, 0xFF9AA7BA, false);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (settingsModule != null) {
            int x = panelX + panelW / 2 - 115, y = panelY + panelH / 2 - 65;
            int[] colors = {0xFF53C8FF, 0xFFFFB347, 0xFFFF6B8A, 0xFF8BE28B, 0xFFC69BFF};
            for (int i = 0; i < colors.length; i++) {
                int cx = x + 12 + i * 40;
                if (inside(mouseX, mouseY, cx, y + 82, 30, 22)) {
                    accent = colors[i];
                    settingsModule = null;
                    return true;
                }
            }
            settingsModule = null;
            return true;
        }

        if (search != null && search.mouseClicked(mouseX, mouseY, button)) return true;
        int tabY = panelY + 70;
        int tabW = (panelW - 24) / 5;
        ModuleCategory[] categories = ModuleCategory.values();
        for (int i = 0; i < categories.length; i++) {
            int x = panelX + 12 + (i % 5) * tabW;
            int y = tabY + (i / 5) * 24;
            if (inside(mouseX, mouseY, x, y, tabW - 3, 20)) {
                selectedCategory = categories[i];
                scroll = 0;
                return true;
            }
        }

        int listY = panelY + 122;
        int listBottom = panelY + panelH - 16;
        if (mouseY >= listY && mouseY < listBottom) {
            int index = (int) ((mouseY - listY + scroll) / ROW_H);
            List<Module> modules = filteredModules();
            if (index >= 0 && index < modules.size()) {
                Module module = modules.get(index);
                int rowY = listY + index * ROW_H - scroll;
                if (mouseX >= panelX + panelW - 48 && mouseX <= panelX + panelW - 12) {
                    settingsModule = module;
                } else {
                    module.setEnabled(!module.enabled());
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int max = Math.max(0, filteredModules().size() * ROW_H - (panelH - 145));
        scroll = Math.max(0, Math.min(max, scroll - (int) (verticalAmount * ROW_H * 2)));
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() { return false; }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
}
